# optimization/variational_optimization.py
import pennylane as qml
from pennylane import numpy as np

def variational_circuit(weights):
    # Create a 2-qubit circuit with a simple variational ansatz
    qml.RX(weights[0], wires=0)
    qml.RY(weights[1], wires=1)
    qml.CNOT(wires=[0, 1])
    return qml.expval(qml.PauliZ(0))

def run_variational_optimization():
    # Define quantum device with 2 wires
    dev = qml.device("default.qubit", wires=2)
    
    @qml.qnode(dev)
    def circuit(weights):
        return variational_circuit(weights)
    
    # Cost function to minimize (could be seen as an energy error)
    def cost(weights):
        return circuit(weights)
    
    # Optimize using gradient descent
    opt = qml.GradientDescentOptimizer(stepsize=0.1)
    weights = np.array([0.1, 0.2], requires_grad=True)
    
    print("Starting variational optimization...")
    for i in range(100):
        weights = opt.step(cost, weights)
        if i % 10 == 0:
            print(f"Iteration {i}: Cost = {cost(weights):.4f}")
    
    print("Optimized weights:", weights)
    print("Final cost:", cost(weights))
    
if __name__ == '__main__':
    run_variational_optimization()
