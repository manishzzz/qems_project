# QEMS Design Document

## Overview

The QEMS prototype is divided into three components:

1. **Entanglement & Quantum Memory:**  
   - Uses Qiskit to prepare a GHZ state and simulate a “storage” period with a barrier.
2. **Superposition Charge/Discharge:**  
   - Uses Cirq to prepare a qubit in superposition representing dual states.
3. **Optimization Module:**  
   - Uses PennyLane to optimize a simple cost function that can be interpreted as tuning the energy or stability parameters.

## Future Work

- Expand to more qubits or qudits.
- Include noise models to simulate decoherence.
- Integrate classical data (e.g. weather, demand) to drive optimization.
