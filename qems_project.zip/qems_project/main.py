# main.py
import sys
from entanglement.ghz_state import run_ghz_simulation
from superposition.superposition_demo import run_superposition_demo
from optimization.variational_optimization import run_variational_optimization

def main():
    print("=== QEMS Prototype ===")
    print("\n[1] Entanglement and Memory Simulation (GHZ state)")
    run_ghz_simulation()

    print("\n[2] Superposition-based Charge/Discharge Simulation")
    run_superposition_demo()

    print("\n[3] Hybrid Quantum-Classical Optimization")
    run_variational_optimization()

if __name__ == '__main__':
    main()
