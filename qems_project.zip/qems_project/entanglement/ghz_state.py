# entanglement/ghz_state.py
from qiskit import QuantumCircuit, Aer, execute
from qiskit.visualization import plot_histogram
import matplotlib.pyplot as plt

def run_ghz_simulation():
    # Create a 3-qubit circuit with 3 classical bits
    qc = QuantumCircuit(3, 3)

    # Prepare GHZ state: (|000> + |111>)/sqrt(2)
    qc.h(0)
    qc.cx(0, 1)
    qc.cx(0, 2)
    
    # Barrier simulates the quantum memory/storage phase
    qc.barrier()
    
    # Measure all qubits
    qc.measure([0, 1, 2], [0, 1, 2])
    
    # Print and draw the circuit
    print(qc.draw(output='text'))
    
    # Execute on simulator
    backend = Aer.get_backend('qasm_simulator')
    job = execute(qc, backend, shots=1024)
    result = job.result()
    counts = result.get_counts(qc)
    print("GHZ Simulation Results:", counts)
    
    # Plot histogram
    plot_histogram(counts)
    plt.show()

if __name__ == '__main__':
    run_ghz_simulation()
