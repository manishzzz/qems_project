# superposition/superposition_demo.py
import cirq

def run_superposition_demo():
    # Create one qubit
    qubit = cirq.LineQubit(0)
    
    # Build the circuit: apply Hadamard to create superposition and measure.
    circuit = cirq.Circuit(
        cirq.H(qubit),
        cirq.measure(qubit, key='result')
    )
    
    print("Superposition Circuit:")
    print(circuit)
    
    # Simulate the circuit
    simulator = cirq.Simulator()
    result = simulator.run(circuit, repetitions=1000)
    print("Superposition Measurement Histogram:", result.histogram(key='result'))

if __name__ == '__main__':
    run_superposition_demo()
